var searchData=
[
  ['print_5fheader_0',['print_header',['../eleicoes_8php.html#a445389ddfffe227dbc6d8add234ced18',1,'eleicoes.php']]],
  ['print_5ftable_5fhead_5fprefeitos_1',['print_table_head_prefeitos',['../eleicoes_8php.html#a6b61e415ec075133f0c4cf246c71c2d6',1,'eleicoes.php']]],
  ['print_5ftable_5fhead_5fvereadores_2',['print_table_head_vereadores',['../eleicoes_8php.html#aca392b2f53056eeb40bf85ca439e6bd7',1,'eleicoes.php']]],
  ['print_5ftable_5fprefeitos_3',['print_table_prefeitos',['../eleicoes_8php.html#a6d0fd7e26f7dff3fa392945df598dd93',1,'eleicoes.php']]],
  ['print_5ftable_5fvereadores_4',['print_table_vereadores',['../eleicoes_8php.html#ac15c34eb474cb5c737628bd01193bbde',1,'eleicoes.php']]],
  ['print_5fvencedor_5fprefeito_5',['print_vencedor_prefeito',['../eleicoes_8php.html#a5c87eaedba563e5bdbbb12653899126a',1,'eleicoes.php']]],
  ['print_5fvencedor_5fvereador_6',['print_vencedor_vereador',['../eleicoes_8php.html#adc325d29de78e8b150f70633116e2950',1,'eleicoes.php']]]
];
